char **SplitArgs(char *, int(*)(char), int *);
