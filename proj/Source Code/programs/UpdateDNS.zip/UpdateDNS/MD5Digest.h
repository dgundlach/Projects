char *MD5Digest(char *);

