#define GOHOME_OK                       0
#define GOHOME_NO_PASSWORD_ENTRY        -1
#define GOHOME_CANT_GO_HOME             -2

int GoHome(void);

