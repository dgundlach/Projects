void HexDump (void *, int, int);
