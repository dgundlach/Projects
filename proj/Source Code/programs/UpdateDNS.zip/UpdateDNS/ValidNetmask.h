int ValidNetmask(in_addr_t);
