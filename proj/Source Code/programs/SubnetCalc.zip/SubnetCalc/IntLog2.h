int IntLog2(unsigned int);
