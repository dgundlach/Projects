int BitCount(unsigned int);
